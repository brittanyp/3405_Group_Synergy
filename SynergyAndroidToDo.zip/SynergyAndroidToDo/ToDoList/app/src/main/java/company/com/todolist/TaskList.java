package company.com.todolist;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.Switch;

public class TaskList extends AppCompatActivity {
    private EditText editText1, editText2, editText3, editText4, editText5, editText6, editText7,editText8,editText9,editText10, editText11, editText12;
    private Switch switch1, switch2, switch3, switch4, switch5, switch6, switch7, switch8, switch9, switch10, switch11, switch12;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_task_list);

        // Trying to hide the Title Bar that is put there, so there is more space to use.
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }

        // Declaration of the xml edit texts and checkboxes
        editText1 = (EditText) findViewById(R.id.editText1);
        editText2 = (EditText) findViewById(R.id.editText2);
        editText3 = (EditText) findViewById(R.id.editText3);
        editText4 = (EditText) findViewById(R.id.editText4);
        editText5 = (EditText) findViewById(R.id.editText5);
        editText6 = (EditText) findViewById(R.id.editText6);
        editText7 = (EditText) findViewById(R.id.editText7);
        editText8 = (EditText) findViewById(R.id.editText8);
        editText9 = (EditText) findViewById(R.id.editText9);
        editText10 = (EditText) findViewById(R.id.editText10);
        editText11 = (EditText) findViewById(R.id.editText11);
        editText12 = (EditText) findViewById(R.id.editText12);

        switch1 = (Switch) findViewById(R.id.switch1);
        switch2 = (Switch) findViewById(R.id.switch2);
        switch3 = (Switch) findViewById(R.id.switch3);
        switch4 = (Switch) findViewById(R.id.switch4);
        switch5 = (Switch) findViewById(R.id.switch5);
        switch6 = (Switch) findViewById(R.id.switch6);
        switch7 = (Switch) findViewById(R.id.switch7);
        switch8 = (Switch) findViewById(R.id.switch8);
        switch9 = (Switch) findViewById(R.id.switch9);
        switch10 = (Switch) findViewById(R.id.switch10);
        switch11 = (Switch) findViewById(R.id.switch11);
        switch12 = (Switch) findViewById(R.id.switch12);

        // Getting the saved values for each sections value
        SharedPreferences sharedPreferences = getSharedPreferences("myPref", Context.MODE_PRIVATE);

        // Setting the values for the edit texts and the switches
        editText1.setText(sharedPreferences.getString("week1", "Complete this"));
        editText2.setText(sharedPreferences.getString("week2", "Complete this"));
        editText3.setText(sharedPreferences.getString("week3", "Complete this"));
        editText4.setText(sharedPreferences.getString("week4", "Complete this"));
        editText5.setText(sharedPreferences.getString("week5", "Complete this"));
        editText6.setText(sharedPreferences.getString("week6", "Complete this"));
        editText7.setText(sharedPreferences.getString("week7", "Complete this"));
        editText8.setText(sharedPreferences.getString("week8", "Complete this"));
        editText9.setText(sharedPreferences.getString("week9", "Complete this"));
        editText10.setText(sharedPreferences.getString("week10", "Complete this"));
        editText11.setText(sharedPreferences.getString("week11", "Complete this"));
        editText12.setText(sharedPreferences.getString("week12", "Complete this"));

        switch1.setChecked(sharedPreferences.getBoolean("switch1", true));
        switch2.setChecked(sharedPreferences.getBoolean("switch2", false));
        switch3.setChecked(sharedPreferences.getBoolean("switch3", false));
        switch4.setChecked(sharedPreferences.getBoolean("switch4", false));
        switch5.setChecked(sharedPreferences.getBoolean("switch5", false));
        switch6.setChecked(sharedPreferences.getBoolean("switch6", false));
        switch7.setChecked(sharedPreferences.getBoolean("switch7", false));
        switch8.setChecked(sharedPreferences.getBoolean("switch8", false));
        switch9.setChecked(sharedPreferences.getBoolean("switch9", false));
        switch10.setChecked(sharedPreferences.getBoolean("switch10", false));
        switch11.setChecked(sharedPreferences.getBoolean("switch11", false));
        switch12.setChecked(sharedPreferences.getBoolean("switch12", false));


    }


    public void SaveBtnPress(View view) {

        // Save all changes to shared preferences and close the activity

        SharedPreferences sharedPreferences = getSharedPreferences("myPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        boolean complete1 = switch1.isChecked();
        boolean complete2 = switch2.isChecked();
        boolean complete3 = switch3.isChecked();
        boolean complete4 = switch4.isChecked();
        boolean complete5 = switch5.isChecked();
        boolean complete6 = switch6.isChecked();
        boolean complete7 = switch7.isChecked();
        boolean complete8 = switch8.isChecked();
        boolean complete9 = switch9.isChecked();
        boolean complete10 = switch10.isChecked();
        boolean complete11 = switch11.isChecked();
        boolean complete12 = switch12.isChecked();

        String task1 = editText1.getText().toString();
        String task2 = editText2.getText().toString();
        String task3 = editText3.getText().toString();
        String task4 = editText4.getText().toString();
        String task5 = editText5.getText().toString();
        String task6 = editText6.getText().toString();
        String task7 = editText7.getText().toString();
        String task8 = editText8.getText().toString();
        String task9 = editText9.getText().toString();
        String task10 = editText10.getText().toString();
        String task11 = editText11.getText().toString();
        String task12 = editText12.getText().toString();

        editor.putString("week1", task1);
        editor.putString("week2", task2);
        editor.putString("week3", task3);
        editor.putString("week4", task4);
        editor.putString("week5", task5);
        editor.putString("week6", task6);
        editor.putString("week7", task7);
        editor.putString("week8", task8);
        editor.putString("week9", task9);
        editor.putString("week10", task10);
        editor.putString("week11", task11);
        editor.putString("week12", task12);

        editor.putBoolean("switch1", complete1);
        editor.putBoolean("switch2", complete2);
        editor.putBoolean("switch3", complete3);
        editor.putBoolean("switch4", complete4);
        editor.putBoolean("switch5", complete5);
        editor.putBoolean("switch6", complete6);
        editor.putBoolean("switch7", complete7);
        editor.putBoolean("switch8", complete8);
        editor.putBoolean("switch9", complete9);
        editor.putBoolean("switch10", complete10);
        editor.putBoolean("switch11", complete11);
        editor.putBoolean("switch12", complete12);

        editor.apply();

        Intent intent = new Intent(TaskList.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

}
